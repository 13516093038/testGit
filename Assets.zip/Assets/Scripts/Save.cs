using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Save 
{
    public bool isActive=true;
    public List<bool> isSign = new List<bool>();
}
