using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class EventTriggerTest : MonoBehaviour,IPointerClickHandler
{
    // Start is called before the first frame update
    void Start()
    {
        EventTrigger eventTrigger = gameObject.GetComponent<EventTrigger>();
        if (eventTrigger == null)
        {
            eventTrigger = gameObject.AddComponent<EventTrigger>();
        }
        //eventTrigger.OnPointerDown(PointerEventData eventDate);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void onClick()
    {
        Debug.Log("asd");
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log("click");
        //throw new System.NotImplementedException();
    }
}
