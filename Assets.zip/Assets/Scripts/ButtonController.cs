using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class ButtonController : MonoBehaviour
{
    private Button button1;
    public Image image;
    public Image image2;
    //public Text text2;
    // Start is called before the first frame update
    void Start()
    {
        image2.gameObject.SetActive(false);
        image.gameObject.SetActive(false);
        button1 = transform.Find("Button1").GetComponent<Button>();
        button1.onClick.AddListener(()=> {
            OnClickButton1(1);

	});
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnClickButton1(int i)
    {
        image.gameObject.SetActive(true);
    }
    public void OnClickButton2()
    {
        image.gameObject.SetActive(false);
    }
    public void OnClickButton3()
    {
        image2.gameObject.SetActive(false);
    }

}
