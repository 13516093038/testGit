using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    //ictionary<string, bool> data = new Dictionary<string, bool>();
    string today;
    public Button button4;
    int day;
    // Start is called before the first frame update
    void Start()
    {
        today = DateTime.Now.DayOfWeek.ToString();
        SetDay();
        for (int i = 1; i <=7; i++) {
            //data.Add(i.ToString(), false);
            GameObject obj = (GameObject)Instantiate(Resources.Load("Image/image1"), transform);
            obj.transform.localPosition = new Vector3(-240+i * 60, 50, 0);
            ImageController image = obj.GetComponent<ImageController>();
            image.SetText(i);
            image.SetToday(day);
        }
        if (day == 1)
        {
            button4.interactable = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void SetDay()
    {
        if (today == "Monday")
            day = 1;
        else if (today == "Tuesday")
            day = 2;
        else if (today == "Wednesday")
            day = 3;
        else if (today == "Thursday")
            day = 4;
        else if (today == "Friday")
            day = 5;
        else if (today == "Saturday")
            day = 6;
        else if (today == "Sunday")
            day = 7;
    }
    public void OnClickButton4()
    {
        ImageController image = transform.GetChild(day).GetComponent<ImageController>();
        day--;
        //PlayerPrefs.SetInt("day", day);
        //Debug.Log(day);
        image.SetToday(day);
        image.SignInReplenishment();
        PlayerPrefs.SetInt("isSign" + day, 1);
        if (day == 1)
        {
            button4.interactable = false;
        }
    }
    private Save CreateSaveGo() {

        Save save = new Save();
        return save;

    }

}
public class ReceiveAward
{
    public Dictionary<int, string> award = new Dictionary<int, string>();

    public ReceiveAward()
    {
        award.Add(1, "第一天的奖励");
        award.Add(2, "第二天的奖励");
        award.Add(3, "第三天的奖励");
        award.Add(4, "第四天的奖励");
        award.Add(5, "第五天的奖励");
        award.Add(6, "第六天的奖励");
        award.Add(7, "第七天的奖励");
    }
}


