using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;


public class ImageController : MonoBehaviour
{
    ReceiveAward receiveAward;
    Button button;
    Text mytext;
    Image image2;
    Text text2;
    int intday;
    int today;
    // Start is called before the first frame update
    void OnEnable()
    {
        receiveAward = new ReceiveAward();
        image2 = transform.parent.parent.GetChild(2).GetComponent<Image>();
        text2 = image2.transform.GetChild(2).GetComponent<Text>();
        mytext = transform.GetChild(0).GetComponent<Text>();
        button = transform.GetComponent<Button>();
        button.onClick.AddListener(OnButtonClick);
        if (intday != today)
        {
            button.enabled = false;
        }
        if (intday <= today)
        {
            if (1 == PlayerPrefs.GetInt("isSign" + intday)) {

                mytext.text = "已签到";
                button.enabled = false;
            }

                
            else
                mytext.text = "未签到";
        }
     
        //Translatebutton();

    }
    private void Start()
    {
        Debug.Log(this.name);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void SetText(int day)
    {
        mytext.text = day.ToString();
        intday = day;
    }
    public void SetToday(int today)
    {
        this.today = today;
    }
    public void SignInReplenishment()
    {
        mytext.text = "已签到";
        image2.gameObject.SetActive(true);
        text2.text = receiveAward.award[today];
    }

    public void OnButtonClick()
    {
        if (intday == today)
        {
            PlayerPrefs.SetInt("isSign" + intday, 1);
            mytext.text = "已签到";
            image2.gameObject.SetActive(true);
            text2.text = receiveAward.award[today];
            button.enabled = false;

        }
    }
    public void Translatebutton()
    {
        ColorBlock cb = new ColorBlock();
        cb.disabledColor = Color.blue;
        button.colors = cb;
    }
    
    
        
    
}
